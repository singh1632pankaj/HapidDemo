//
//  LoginVC.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit

class LoginVC: UIViewController {
    
    @IBOutlet weak var btnReqOtp: UIButton!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    @IBOutlet weak var lbl5: UILabel!
    @IBOutlet weak var lbl6: UILabel!
    @IBOutlet weak var lbl7: UILabel!

    @IBOutlet weak var lblAlertMob: UILabel!

    @IBOutlet weak var txtMoblieNumber: UITextField!
    @IBOutlet weak var btnGoogle: UIButton!
    @IBOutlet weak var btnFacebook: UIButton!
    
    @IBOutlet weak var btnBack: UIButton!
    
    var mobileNumb = Int()
    var otp = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUp()
        hideKeyboardWhenTappedAround()
        
        self.lblAlertMob.isHidden = true
        txtMoblieNumber.delegate = self
        txtMoblieNumber.addTarget(self, action: #selector(changeInMobNuTextField), for: .editingChanged)
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        btnReqOtp.backgroundColor = UIColor.parpelButton
        btnReqOtp.layer.cornerRadius = 10
        btnReqOtp.clipsToBounds = true

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        removeAnimate()
    }
    
    func setUp(){
        
        lbl1.textColor = UIColor.blackColorText
        lbl2.textColor = UIColor.blackColorText
        lbl3.textColor = UIColor.blackColorText
        lbl4.textColor = UIColor.blackColorText
        lbl5.textColor = UIColor.blackColorText
        lbl6.textColor = UIColor.blackColorText
        lblAlertMob.textColor = UIColor.systemRed

        lbl1.font = UIFont.Montserrat_Bold(size: 24)
        lbl2.font = UIFont.Montserrat_Regular(size: 8)
        lbl3.font = UIFont.Montserrat_Bold(size: 14)
        lbl4.font = UIFont.Montserrat_Regular(size: 12)
        lbl5.font = UIFont.Montserrat_Bold(size: 12)
        lbl6.font = UIFont.Montserrat_Bold(size: 12)
        lblAlertMob.font = UIFont.Montserrat_Bold(size: 9)
        
        lbl1.text = "Enter your mobile\nnumber"
        lbl2.text = "Hello, Welcome Back to Our Account"
        lbl3.text = "+91"
        lbl4.text = "Login With"
        lbl5.text = "Google"
        lbl6.text = "Facebook"
        
        btnReqOtp.titleLabel?.font = UIFont.Montserrat_Bold(size: 12)
        btnReqOtp.setTitleColor(.whiteColorText, for: .normal)
        btnReqOtp.setTitle("Request OTP", for: .normal)
        
        txtMoblieNumber.font = UIFont.Montserrat_Bold(size: 14)
        
        lblAttribute()

    }
    
    func lblAttribute(){
              
        let regularAttribute1 = [
            NSAttributedString.Key.font: UIFont.Montserrat_Regular(size: 11),
            NSAttributedString.Key.foregroundColor : UIColor.blackColorText
            
        ]
        let regularAttribute2 = [
            NSAttributedString.Key.font: UIFont.Montserrat_Regular(size: 11),
            NSAttributedString.Key.foregroundColor : UIColor.orangeColorText
            
        ]
        let regularAttribute3 = [
            NSAttributedString.Key.font: UIFont.Montserrat_Regular(size: 11),
            NSAttributedString.Key.foregroundColor : UIColor.blackColorText
            
        ]
        let regularAttribute4 = [
            NSAttributedString.Key.font: UIFont.Montserrat_Regular(size: 11),
            NSAttributedString.Key.foregroundColor : UIColor.orangeColorText
            
        ]
        let regularText1 = NSAttributedString(string: "By creating passcode you agree with our \n", attributes: regularAttribute1)
        let regularText2 = NSAttributedString(string: "Terms & Conditions ", attributes: regularAttribute2)
        let regularText3 = NSAttributedString(string: "and ", attributes: regularAttribute3)
        let regularText4 = NSAttributedString(string: "Privacy Policy", attributes: regularAttribute4)
        
        let newString = NSMutableAttributedString()
        newString.append(regularText1)
        newString.append(regularText2)
        newString.append(regularText3)
        newString.append(regularText4)

        lbl7.attributedText = newString
        
    }
    
    func showAnimate()
        {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
            UIView.animate(withDuration: 0.40, animations: {
                self.view.alpha = 1.0
                self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)

            });
        }
    
    func removeAnimate()
    {
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0
        }, completion: {(finished : Bool) in
            if(finished)
            {
                self.willMove(toParent: nil)
                self.view.removeFromSuperview()
                self.removeFromParent()
            }
        })
    }

    
    @IBAction func btnReqOtpAct(_ sender: Any) {
        
        let mobilNumber = self.txtMoblieNumber.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        mobileNumb = Int(mobilNumber) ?? 0
    
        let number = mobileNumb
        let numberOfDigits = String(mobileNumb).count
        let firstTwo = mobileNumb / Int(pow(10.0, Double(numberOfDigits - 2)))
        print(firstTwo)

        let a = mobileNumb
        let lastTwo = a % 100
        print(lastTwo)
        
        otp = "\(firstTwo)\(lastTwo)"
        
        if mobilNumber.isEmpty{
            self.lblAlertMob.isHidden = false
            self.lblAlertMob.text = "Please enter mobile number"
            
        }else if !mobilNumber.isEmpty && mobilNumber.count < 10 {
            self.lblAlertMob.isHidden = false
            self.lblAlertMob.text = "Please enter valid mobile number"
            
        }else if !mobilNumber.isValidMobileNo{
            self.lblAlertMob.isHidden = false
            self.lblAlertMob.text = "Please enter valid mobile number"
            
        }else{
            
            print(mobilNumber)
            
            
            let popOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginPopUpVC") as! LoginPopUpVC
            popOverVC.mobileNo = mobileNumb
            popOverVC.otpNo = otp
            self.addChild(popOverVC)
            popOverVC.view.frame = self.view.frame
            self.view.addSubview(popOverVC.view)
            popOverVC.didMove(toParent: self)

        }
     }
     

    @IBAction func btnGoogleAct(_ sender: Any) {
    }
    
    @IBAction func btnFacebookAct(_ sender: Any) {
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)

    }

}

extension LoginVC: UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let textFieldText = textField.text,
        let rangeOfTextToReplace = Range(range, in: textFieldText) else {
          return false
        }
     
        if textField == txtMoblieNumber{

            let mobileNo = self.txtMoblieNumber.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
             if count < 10 {
                self.lblAlertMob.isHidden = false
                self.lblAlertMob.text = "Please enter valid mobile number"
            }

            else if (mobileNo.contains("000000")) && string == "0" {
            self.lblAlertMob.isHidden = false
            self.lblAlertMob.text = "Please enter valid mobile number"
            }
            else{
                self.lblAlertMob.isHidden = true
            }

            return count <= 10
        }
        return true
    }
    
    
    @objc func changeInMobNuTextField(_ textField: UITextField) {
        if textField.text?.count == 0 {
        
            if textField == txtMoblieNumber {
                lblAlertMob.isHidden = true
            }
        }
    }
    
    
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        txtMoblieNumber.becomeFirstResponder()
        return true
    }
}


