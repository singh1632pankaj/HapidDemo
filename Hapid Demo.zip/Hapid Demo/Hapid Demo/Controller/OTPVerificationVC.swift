//
//  OTPVerificationVC.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit

class OTPVerificationVC: UIViewController {
    
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    
    @IBOutlet weak var txt1: MyTextField!
    @IBOutlet weak var txt2: MyTextField!
    @IBOutlet weak var txt3: MyTextField!
    @IBOutlet weak var txt4: MyTextField!
    
    @IBOutlet weak var btnEditMob: UIButton!
    
    @IBOutlet weak var btnBack: UIButton!
    
    @IBOutlet weak var lblAlertOtp: UILabel!

    
    var mobileNo = Int()
    var otpNo = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUp()
        
        print(mobileNo)
        print(otpNo)
        
        txt1.delegate = self
        txt2.delegate = self
        txt3.delegate = self
        txt4.delegate = self
    
        txt1.myDelegate = self
        txt2.myDelegate = self
        txt3.myDelegate = self
        txt4.myDelegate = self
        
        lblAlertOtp.isHidden = true
      
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        btnSubmit.backgroundColor = UIColor.parpelButton
        btnSubmit.layer.cornerRadius = 10
        btnSubmit.clipsToBounds = true

    }
    
    func setUp(){
        
        lbl1.textColor = UIColor.blackColorText
        lbl2.textColor = UIColor.blackColorText
        lbl3.textColor = UIColor.blackColorText
        lbl4.textColor = UIColor.blackColorText

        lbl1.font = UIFont.Montserrat_Bold(size: 24)
        lbl2.font = UIFont.Montserrat_Regular(size: 8)
        lbl3.font = UIFont.Montserrat_Bold(size: 12)
        lbl4.font = UIFont.Montserrat_Regular(size: 12)
        
        txt1.font = UIFont.Montserrat_Bold(size: 14)
        txt2.font = UIFont.Montserrat_Bold(size: 14)
        txt3.font = UIFont.Montserrat_Bold(size: 14)
        txt4.font = UIFont.Montserrat_Bold(size: 14)
    

        
        lblAlertOtp.font = UIFont.Montserrat_Bold(size: 9)
        lblAlertOtp.textColor = UIColor.systemRed

        lbl1.text = "Enter your\nVerification code"
        lbl2.text = "We Have sent the code verification to\nyour mobile number"
        lbl3.text = "+91 \(mobileNo)"
        lbl4.text = "Login With"

        btnSubmit.titleLabel?.font = UIFont.Montserrat_Bold(size: 12)
        btnSubmit.setTitleColor(.whiteColorText, for: .normal)
        btnSubmit.setTitle("Submit", for: .normal)
        
        lblAttribute()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        txt1.addTarget(self, action: #selector(changeInTextField), for: .editingChanged)
        txt2.addTarget(self, action: #selector(changeInTextField), for: .editingChanged)
        txt3.addTarget(self, action: #selector(changeInTextField), for: .editingChanged)
        txt4.addTarget(self, action: #selector(changeInTextField), for: .editingChanged)
    
    }
    
    func lblAttribute(){
              
        let regularAttribute1 = [
            NSAttributedString.Key.font: UIFont.Montserrat_Regular(size: 11),
            NSAttributedString.Key.foregroundColor : UIColor.blackColorText
            
        ]
        let boldAttribute1 = [
            NSAttributedString.Key.font: UIFont.Montserrat_Regular(size: 11),
            NSAttributedString.Key.foregroundColor : UIColor.orangeColorText
            
        ]
      
        let regularText1 = NSAttributedString(string: "don't receive OTP?", attributes: regularAttribute1)
        let boldText1 = NSAttributedString(string: " Resend", attributes: boldAttribute1)
      

        let newString = NSMutableAttributedString()
        newString.append(regularText1)
        newString.append(boldText1)
    
        lbl4.attributedText = newString
        
    }
    
    @IBAction func btnSubmitAct(_ sender: Any) {
        
        let otp1 = self.txt1.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let otp2 = self.txt2.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let otp3 = self.txt3.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let otp4 = self.txt4.text!.trimmingCharacters(in: .whitespacesAndNewlines)

        let npPin = "\(otp1)\(otp2)\(otp3)\(otp4)"
        print(npPin)
        print(otpNo)

        if txt1.text!.isEmpty  || txt2.text!.isEmpty  || txt3.text!.isEmpty || txt4.text!.isEmpty {
            lblAlertOtp.isHidden = false
            lblAlertOtp.text = "Please enter OTP"
            lblAlertOtp.textColor = UIColor.systemRed
        
        }else if npPin != otpNo{
            lblAlertOtp.isHidden = false
            lblAlertOtp.text = "OTP Not Validate"
            lblAlertOtp.textColor = UIColor.systemRed
        }
        else if npPin == self.otpNo{
            
            DispatchQueue.main.async {
            self.lblAlertOtp.isHidden = true
        let refreshAlert = UIAlertController(title: "Hapid Demo", message: "OTP Validate" , preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in

            let vc = AppStoryboard.Main.instance.instantiateViewController(withIdentifier: "CreateProfileVC") as! CreateProfileVC
            vc.mobileNo = self.mobileNo
        self.navigationController?.pushViewController(vc, animated: true)

        }))

        self.present(refreshAlert, animated: true, completion: nil)

        }

        }
    }
    
    @IBAction func btnEditMobAct(_ sender: Any) {
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)

    }
}

extension OTPVerificationVC: UITextFieldDelegate, MyTextFieldDelegate{

    func textFieldDidDelete(_ textField: UITextField) {
        if textField == txt2{
            txt1.becomeFirstResponder()
        }
        if textField == txt3{
            txt2.becomeFirstResponder()
        }
        if textField == txt4{
            txt3.becomeFirstResponder()
        }
        if textField == txt1{
            
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
       
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        lblAlertOtp.isHidden = false
        lblAlertOtp.text = "Please enter valid OTP"
        
        if ((textField.text!) + string).count > 1 {
            if textField == txt1 {
                txt2.text = string
                txt2.becomeFirstResponder()
            }
            if textField == txt2 {
                txt3.text = string
                txt3.becomeFirstResponder()
            }
            if textField == txt3 {
                txt4.text = string
                txt4.becomeFirstResponder()
            }
        
            if textField == txt4{
                lblAlertOtp.isHidden = true
                self.txt4.resignFirstResponder()
            }
            return false
        }
       return true
    }
    
    @objc func changeInTextField(_ textField: UITextField) {
        if textField.text?.count == 1 {
        
            if textField == txt1 {
                txt2.becomeFirstResponder()
            }
            if textField == txt2 {
                txt3.becomeFirstResponder()
            }
            if textField == txt3 {
                txt4.becomeFirstResponder()
            }
        
            if textField == txt4{
                lblAlertOtp.isHidden = true
                self.txt4.resignFirstResponder()

            }
        }
        else {
            if textField == txt2{
                txt1.becomeFirstResponder()
            }
            if textField == txt3{
                txt2.becomeFirstResponder()
            }
            if textField == txt4{
                txt3.becomeFirstResponder()
            }
            if textField == txt1{
                self.txt1.resignFirstResponder()
                lblAlertOtp.isHidden = true
                
            }
        }
    }
    
}

