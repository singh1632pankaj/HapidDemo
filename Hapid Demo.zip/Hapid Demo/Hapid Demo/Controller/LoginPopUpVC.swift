//
//  LoginPopUpVC.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit

class LoginPopUpVC: UIViewController {
  
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    @IBOutlet weak var lbl5: UILabel!
    
    @IBOutlet weak var view1: UIView!
    
    var mobileNo = Int()
    var otpNo = String()
    
    var value1 = ""
    var value2 = ""
    var value3 = ""
    var value4 = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(mobileNo)
        print(otpNo)
        
        let str = otpNo
    
        let index1 = str.index(str.startIndex, offsetBy: 0)
        let index2 = str.index(str.startIndex, offsetBy: 1)
        let index3 = str.index(str.startIndex, offsetBy: 2)
        let index4 = str.index(str.startIndex, offsetBy: 3)
        
        print(str[index1])
        print(str[index2])
        print(str[index3])
        print(str[index4])
        
        value1 = String(str[index1])
        value2 = String(str[index2])
        value3 = String(str[index3])
        value4 = String(str[index4])
     
        setUp()
        showAnimate()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute:{
            
            let popOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "OTPVerificationVC") as! OTPVerificationVC
            popOverVC.mobileNo = self.mobileNo
            popOverVC.otpNo = self.otpNo
            self.addChild(popOverVC)
            popOverVC.view.frame = self.view.frame
            self.view.addSubview(popOverVC.view)
            popOverVC.didMove(toParent: self)
            
        })
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        removeAnimate()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
      
        view1.backgroundColor = UIColor.whiteColorText
        view1.layer.cornerRadius = 10
        view1.clipsToBounds = true

    }
    
    func setUp(){
        
        lbl1.textColor = UIColor.blackColorText
        lbl2.textColor = UIColor.blackColorText
        lbl3.textColor = UIColor.blackColorText
        lbl4.textColor = UIColor.blackColorText
        lbl5.textColor = UIColor.blackColorText

        lbl1.font = UIFont.Montserrat_Bold(size: 13)
        lbl2.font = UIFont.Montserrat_Bold(size:15)
        lbl3.font = UIFont.Montserrat_Bold(size: 15)
        lbl4.font = UIFont.Montserrat_Bold(size: 15)
        lbl5.font = UIFont.Montserrat_Bold(size: 15)
       
        lbl1.text = "Your confirmation code is\n below — enter it  and we'll help\n you get signed in."
        lbl2.text = value1
        lbl3.text = value2
        lbl4.text = value3
        lbl5.text = value4
  
    }
    
    func showAnimate()
        {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
            UIView.animate(withDuration: 0.40, animations: {
                self.view.alpha = 1.0
                self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)

            });
        }
    
    func removeAnimate()
    {
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0
        }, completion: {(finished : Bool) in
            if(finished)
            {
                self.willMove(toParent: nil)
                self.view.removeFromSuperview()
                self.removeFromParent()
            }
        })
    }
    
}
