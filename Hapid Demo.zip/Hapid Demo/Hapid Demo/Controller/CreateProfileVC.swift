//
//  CreateProfileVC.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit
import CoreLocation
import MapKit
import PhotosUI
import Alamofire
import SwiftyJSON

class CreateProfileVC: UIViewController {
    
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    @IBOutlet weak var lbl5: UILabel!
    @IBOutlet weak var lbl6: UILabel!
    @IBOutlet weak var lbl7: UILabel!
    @IBOutlet weak var lbl8: UILabel!
    
    @IBOutlet weak var lblLat: UILabel!
    @IBOutlet weak var lblLong: UILabel!
    
    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var txt3: UITextField!
    @IBOutlet weak var txt4: UITextField!
    
    @IBOutlet weak var lblAlert1: UILabel!
    @IBOutlet weak var lblAlert2: UILabel!
    @IBOutlet weak var lblAlert3: UILabel!
    @IBOutlet weak var lblAlert4: UILabel!

    @IBOutlet weak var btnCureentLoc: UIButton!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnProfile: UIButton!
    
    @IBOutlet weak var btnBack: UIButton!
    
    @IBOutlet weak var imgPick: UIImageView!
    
    let r  = Hapid_DemoClass()

    var pickedImage : UIImage?
    var locationManager = CLLocationManager()
    var currentLocation : CLLocation?
    
    var long = String()
    var latt = String()
    var locName = String()
    
    var pickName = String()
    var uploadImgV = UIImage()
            
    var firstName = String()
    var lastName = String()
    var mobileNo = Int()
    var PostalCode = Int()
    
    var imgUrl:URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUp()
        lblAlert1.isHidden = true
        lblAlert2.isHidden = true
        lblAlert3.isHidden = true
        lblAlert4.isHidden = true
        
        hideKeyboardWhenTappedAround()

        txt1.addTarget(self, action: #selector(changeInFirstNameTextField), for: .editingChanged)
        txt2.addTarget(self, action: #selector(changeInLastNameTextField), for: .editingChanged)
        txt3.addTarget(self, action: #selector(changeInMobileNoField), for: .editingChanged)
        txt4.addTarget(self, action: #selector(changeInPostalCodeTextField), for: .editingChanged)
        
        txt1.delegate = self
        txt2.delegate = self
        txt3.delegate = self
        txt4.delegate = self
        
        lblLat.isHidden = true
        lblLong.isHidden = true
    
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        btnSubmit.backgroundColor = UIColor.parpelButton
        btnSubmit.layer.cornerRadius = 10
        btnSubmit.clipsToBounds = true
        
        imgPick.layer.borderWidth=1.0
        imgPick.layer.masksToBounds = false
        imgPick.layer.borderColor = UIColor.whiteColorText.cgColor
        imgPick.layer.cornerRadius = imgPick.frame.size.height/2
        imgPick.clipsToBounds = true

    }
    
    func setUp(){
        
        lbl1.textColor = UIColor.blackColorText
        lbl2.textColor = UIColor.blackColorText
        lbl3.textColor = UIColor.blackColorText
        lbl4.textColor = UIColor.blackColorText
        lbl5.textColor = UIColor.blackColorText
        lbl6.textColor = UIColor.whiteColorText
        lbl7.textColor = UIColor.gray
        lbl8.textColor = UIColor.blackColorText
        
        lblLat.textColor = UIColor.blackColorText
        lblLong.textColor = UIColor.blackColorText
        
        lbl1.font = UIFont.Montserrat_Bold(size: 20)
        lbl2.font = UIFont.Montserrat_Regular(size: 12)
        lbl3.font = UIFont.Montserrat_Regular(size: 12)
        lbl4.font = UIFont.Montserrat_Regular(size: 12)
        lbl5.font = UIFont.Montserrat_Regular(size: 12)
        lbl6.font = UIFont.Montserrat_Regular(size: 12)
        lbl7.font = UIFont.Montserrat_Bold(size: 13)
        lbl8.font = UIFont.Montserrat_Regular(size: 12)
        
        lblLat.font = UIFont.Montserrat_Bold(size: 9)
        lblLong.font = UIFont.Montserrat_Bold(size: 9)
        
        lblAlert1.textColor = UIColor.systemRed
        lblAlert2.textColor = UIColor.systemRed
        lblAlert3.textColor = UIColor.systemRed
        lblAlert4.textColor = UIColor.systemRed
        
        lblAlert1.font = UIFont.Montserrat_Bold(size: 9)
        lblAlert2.font = UIFont.Montserrat_Bold(size: 9)
        lblAlert3.font = UIFont.Montserrat_Bold(size: 9)
        lblAlert4.font = UIFont.Montserrat_Bold(size: 9)

        txt1.font = UIFont.Montserrat_Bold(size: 12)
        txt2.font = UIFont.Montserrat_Bold(size: 12)
        txt3.font = UIFont.Montserrat_Bold(size: 12)
        txt4.font = UIFont.Montserrat_Bold(size: 12)
        
        lbl1.text = "Create profile"
        lbl2.text = "Set profile"
        lbl3.text = "First name"
        lbl4.text = "Last Name"
        lbl5.text = "Phone"
        lbl6.text = "pick your current location"
        lbl7.text = "or"
        lbl8.text = "post code"

        btnSubmit.titleLabel?.font = UIFont.Montserrat_Bold(size: 12)
        btnSubmit.setTitleColor(.whiteColorText, for: .normal)
        btnSubmit.setTitle("Submit", for: .normal)
                        
    }
   
    @IBAction func btnCurrentLocAct(_ sender: Any) {
        getCurentLocation()
        lblLat.isHidden = false
        lblLong.isHidden = false
       
    }
    
    @IBAction func btnSubmitAct(_ sender: Any) {
        
        let firstName   = self.txt1.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let lastName = self.txt2.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let mobileNu = self.txt3.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let postalCode = self.txt4.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if firstName.isEmpty && lastName.isEmpty && mobileNu.isEmpty && postalCode.isEmpty {
            self.lblAlert1.isHidden = false
            self.lblAlert1.text = "Please Enter First Name"
            self.lblAlert2.isHidden = false
            self.lblAlert2.text = "Please Enter Last Name"
            self.lblAlert3.isHidden = false
            self.lblAlert3.text = "Please Enter Mobile Number"
            self.lblAlert4.isHidden = false
            self.lblAlert4.text = "Please Enter Postal Code"
            return
            
        }else if firstName.isEmpty{
            self.lblAlert1.isHidden = false
            self.lblAlert1.text = "Please Enter First Name"
            return
            
        }else if lastName.isEmpty{
            self.lblAlert2.isHidden = false
            self.lblAlert2.text = "Please Enter Last Name"
            return

       }else if mobileNu.isEmpty{
        self.lblAlert3.isHidden = false
        self.lblAlert3.text = "Please Enter Mobile Number"
        return
        
      }else if !mobileNu.isEmpty && mobileNu.count < 10{
        self.lblAlert3.isHidden = false
        self.lblAlert3.text = "Please Enter Valid Mobile Number"
        return
          
      }else if (mobileNu.contains("0000000000")) {
        self.lblAlert3.isHidden = false
        self.lblAlert3.text = "Please Enter Valid Mobile Number"
        return
          
      }else if postalCode.isEmpty{
        self.lblAlert4.isHidden = false
        self.lblAlert4.text = "Please Enter Postal Code"
        return
        
     }else if !postalCode.isEmpty && postalCode.count < 6{
        self.lblAlert4.isHidden = false
        self.lblAlert4.text = "Please Enter Valid Postal Code"
        return
         
     }else if (postalCode.contains("000000")) {
        self.lblAlert4.isHidden = false
        self.lblAlert4.text = "Please Enter Valid Postal Code"
        return
    }
        else {
           // metaDataUploadFromMultiPartFormAPI()
            
            let refreshAlert = UIAlertController(title: "Hapid Demo", message: "SUCCESS" , preferredStyle: UIAlertController.Style.alert)

            refreshAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in
                
                self.navigationController?.popToRootViewController(animated: true)

            }))

            self.present(refreshAlert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnUploadProfAct(_ sender: Any) {
     pickPhoto()
    }
    
    @IBAction func btnBackAct(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)

    }

}

extension CreateProfileVC :CLLocationManagerDelegate {
    
    func getCurentLocation(){
        
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        
        } else {
            print("Location services are not enabled");
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let location = locations.last! as CLLocation
        /* you can use these values*/
        let lat:String = "\(location.coordinate.latitude)"
        let lon:String = "\(location.coordinate.longitude)"
        latt = lat
        long = lon
        GlobalClass.lat = location.coordinate.latitude
        GlobalClass.long = location.coordinate.longitude
        print(latt)
        print(long)
    
        let geoCoder = CLGeocoder()
        geoCoder.reverseGeocodeLocation(location, completionHandler:{
            placemarks, error -> Void in
            // Place details
            guard let placeMark = placemarks?.first else { return }
            if let city = placeMark.locality {
                print(city)
                GlobalClass.city = city
                
            }
            // City
            if let location = placeMark.subAdministrativeArea {
                print(location)
                self.locName = location
                
            }
            
            // Country
            if let country = placeMark.country {
                print(country)
            }
        })
        
        lblLat.text = "Lat = \(latt)"
        lblLong.text = "Long = \(long)"
        locationManager.stopUpdatingLocation()
    }
}

extension CreateProfileVC : UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    fileprivate func camera() {
        self.locationManager.startUpdatingLocation()
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            self.present(imagePicker, animated: true, completion: nil)
            
        }else{
            print("Camera Not Avalable")
        }
    }
    
    fileprivate func photoLibrary() {
        // Do what you want to do.
        let photoLibrary = PHPhotoLibrary.shared()
        let config = PHPickerConfiguration(photoLibrary: photoLibrary)
        let imagePicker = PHPickerViewController(configuration: config)
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
    }

    
    func pickPhoto(){
        let actionSheet = UIAlertController(title: "Photo Source", message: "choose a source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action:UIAlertAction) in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action:UIAlertAction) in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
        
    }
    
    func noCamera(){
        let alertVC = UIAlertController(title: "No Camera", message: "Sorry, Gallery is not accessible.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style:.default, handler: nil)
        alertVC.addAction(okAction)
        present(alertVC, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            pickedImage.pngData()
            self.pickedImage = pickedImage
            imgPick.contentMode = .scaleAspectFill
            imgPick.image = pickedImage
            uploadImgV = pickedImage
        }
        
        locationManager.stopUpdatingLocation()
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func createImageName() -> String {
        let shopName = "VLE"
        let dateTimee = Date().getLocalTime(format: "ddMMMyyyy_hh:mm").0
        let imageName = "\(shopName)_\(dateTimee)"
        UserDefaults.standard.set(imageName, forKey: "ImageName")
        print(imageName)
        return imageName
    }
    
}

extension CreateProfileVC: PHPickerViewControllerDelegate {

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        //self.btnProceed.isUserInteractionEnabled = false
        for item in results {
            item.itemProvider.loadFileRepresentation(forTypeIdentifier: "public.item") { (url, error) in
                if error != nil {
                    print("error (error!)")
                } else {
                    DispatchQueue.main.async {
                        if let url = url {
                            if let imageData = try? Data(contentsOf: url) {
                                self.uploadImgV = UIImage(data: imageData) ?? UIImage()
                                self.imgPick.image = self.uploadImgV
                                let urlString = url.absoluteString

                            }

                        }
                    }
                }
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
}


extension CreateProfileVC: UITextFieldDelegate{

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        

        guard let textFieldText = textField.text,
        let rangeOfTextToReplace = Range(range, in: textFieldText) else {
          return false
        }
        
        if textField == txt1{
            
            let firstName = self.txt1.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string
            
            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
        
            if "\(firstName)".count == 1{
                self.lblAlert1.isHidden = false
                self.lblAlert1.text = "Please Enter First Name"
            }
            else{
            self.lblAlert1.isHidden = true

            }
            
            return count <= 26
            
        }
        
        else if textField == txt2{

            let lastName = self.txt2.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
            
            if "\(lastName)".count == 1{
                self.lblAlert2.isHidden = false
                self.lblAlert2.text = "Please Enter Last Name"

            }
            else{
                self.lblAlert2.isHidden = true
            }

            
            return count <= 26
            
        }    else if textField == txt3 {
            
            let mobileNumber = self.txt3.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
             if count < 10 {
                self.lblAlert3.isHidden = false
                self.lblAlert3.text = "Please Enter Mobile Number"
            }

            else if (mobileNumber.contains("0000000000")) && string == "0" {
            self.lblAlert3.isHidden = false
            self.lblAlert3.text = "Please Valid Mobile Number"
            }

            else{
                self.lblAlert3.isHidden = true
            }

            return count <= 10
        }    else if textField == txt4{
            
            let postalCode = self.txt4.text!.trimmingCharacters(in: .whitespacesAndNewlines) + string

            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            
             if count < 6 {
                self.lblAlert4.isHidden = false
                self.lblAlert4.text = "Please Enter Postal Code"
            }

            else if (postalCode.contains("000000")) && string == "0" {
            self.lblAlert4.isHidden = false
            self.lblAlert4.text = "Please Enter Valid Postal Code"
            }
            else{
                self.lblAlert4.isHidden = true
            }

            return count <= 6
        }
        return true
    }
    
    
    @objc func changeInFirstNameTextField(_ textField: UITextField) {
        if textField.text?.count == 0 {
        
            if textField == txt1 {
                lblAlert1.isHidden = true
            }
        }
    }
    @objc func changeInLastNameTextField(_ textField: UITextField) {
            if textField.text?.count == 0 {
            
                if textField == txt2 {
                    lblAlert2.isHidden = true
                }
            }
    }
    
    @objc func changeInMobileNoField(_ textField: UITextField) {
        if textField.text?.count == 0 {
        
            if textField == txt3 {
                lblAlert3.isHidden = true
            }
        }
    }
    @objc func changeInPostalCodeTextField(_ textField: UITextField) {
            if textField.text?.count == 0 {
            
                if textField == txt4 {
                    lblAlert4.isHidden = true
                }
            }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == txt1 {
            txt2.becomeFirstResponder()
            return true
        }
        else if textField == txt2 {
            txt3.becomeFirstResponder()
            return true
        }
        else if textField == txt4 {
            txt3.becomeFirstResponder()
            return true
        }
        else{
            textField.resignFirstResponder()
            return true
        }
    }
}

extension CreateProfileVC {
    
    //MARK: - FormData API
    
    func metaDataUploadFromMultiPartFormAPI() {
        
        DispatchQueue.main.async {
            self.r.startLoader(self.view)
        }
     
        let parameters = ["firstName": "appRef",
                          "lastName":"secCode",
                          "lat":"23.456",
                          "long":"22.345",
                          "mobileNumber":"1234567890",
                          "PostalCode":"123456"
        ]
        
        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(self.imgUrl!, withName: "file",fileName: "file.jpeg", mimeType: "image/jpeg")
            for (key, value) in parameters {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
                print(value)
            } //Optional for extra parameters
        },
                  
        to:"APIUrl/endPoint").responseJSON
        { (response) in
            
            print(response)
    
            switch response.result {
                
            case .success(let JSON):
                print("Success: \(response)")
       
            case .failure(let error):
                self.r.stopLoader()
                print("Failure: \(error.localizedDescription)")

            }
            
        }
        
    }
}

