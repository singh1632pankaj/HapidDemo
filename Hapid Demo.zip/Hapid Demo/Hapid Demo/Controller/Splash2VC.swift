//
//  Splash2VC.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit

class Splash2VC: UIViewController {
    
    @IBOutlet weak var btnGetStarted: UIButton!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUp()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        btnGetStarted.backgroundColor = UIColor.parpelButton
        btnGetStarted.layer.cornerRadius = 10
        btnGetStarted.clipsToBounds = true

    }
    
    func setUp(){
        
        lbl1.textColor = UIColor.blackColorText
        lbl1.font = UIFont.Montserrat_Bold(size: 20)
        lbl1.text = "Best Markitplac"
        
        lbl2.textColor = UIColor.blackColorText
        lbl2.font = UIFont.Montserrat_Regular(size: 10)
        lbl2.text = "O On-Time Departures. Pay just for your seat. No Refusal from our end. Spacious & Comfortable Seating. Female passengers safety standards. Onboard Refreshments. Cab Tracking through Maps"

        btnGetStarted.titleLabel?.font = UIFont.Montserrat_Bold(size: 12)
        btnGetStarted.setTitleColor(.whiteColorText, for: .normal)

        btnGetStarted.setTitle("Get Started", for: .normal)

    }
    
    @IBAction func btnGetStartedAct(_ sender: Any) {
      
        let vc = AppStoryboard.Main.instance.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(vc, animated: true)

    }
  
}
