//
//  UIFonts+CustomFonts.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit
import Foundation
import CoreLocation

let IS_IPAD                             = (UIDevice.current.userInterfaceIdiom == .pad)
let IS_IPHONE                           = (UIDevice.current.userInterfaceIdiom == .phone)
let IS_RETINA                           = (UIScreen.main.scale >= 2.0)
let SCREEN_WIDTH                        = (UIScreen.main.bounds.size.width)
let SCREEN_HEIGHT                       = (UIScreen.main.bounds.size.height)
let SCREEN_MAX_LENGTH                   = (max(SCREEN_WIDTH, SCREEN_HEIGHT))
let SCREEN_MIN_LENGTH                   = (min(SCREEN_WIDTH, SCREEN_HEIGHT))
let IS_IPAD_PRO_1366                    = (IS_IPAD && SCREEN_MAX_LENGTH == 1366.0)
let IS_IPAD_PRO_1112                    = (IS_IPAD && SCREEN_MAX_LENGTH == 1112.0)
let IS_IPAD_PRO_1024                    = (IS_IPAD && SCREEN_MAX_LENGTH == 1024.0)
let IS_IPAD_PRO_1180                    = (IS_IPAD && SCREEN_MAX_LENGTH == 1180.0)
let IS_IPAD_PRO_1080                    = (IS_IPAD && SCREEN_MAX_LENGTH == 1080.0)
let IS_IPAD_PRO_1194                    = (IS_IPAD && SCREEN_MAX_LENGTH == 1194.0)

let IS_IPHONE_4_OR_LESS                 = (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
let IS_IPHONE_5                         = (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
let IS_IPHONE_6                         = (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
let IS_IPHONE_6P                        = (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)
let IS_IPHONE_11Pro                     = (IS_IPHONE && SCREEN_MAX_LENGTH == 812.0)
let IS_IPHONE_11ProMax                  = (IS_IPHONE && SCREEN_MAX_LENGTH == 896.0)
let IS_IPHONE_12                        = (IS_IPHONE && SCREEN_MAX_LENGTH == 844.0)
let IS_IPHONE_12Pro                     = (IS_IPHONE && SCREEN_MAX_LENGTH == 844.0)
let IS_IPHONE_12ProMax                  = (IS_IPHONE && SCREEN_MAX_LENGTH == 926.0)


private func calculateSize(enter size : CGFloat) -> CGFloat {
    var sizeOfFont : CGFloat?
    
    if IS_IPHONE_4_OR_LESS {
        sizeOfFont = size - 2.0
    }
    if IS_IPHONE_5 {
        sizeOfFont = size + 1.0
    }
    if IS_IPHONE_6 {
        sizeOfFont = size + 3.0
    }
    if IS_IPHONE_6P {
        sizeOfFont = size + 3.0
    }
    if IS_IPHONE_11Pro {
        sizeOfFont = size + 3.0
    }
    if IS_IPHONE_11ProMax {
        sizeOfFont = size + 4.0
    }
    
    if IS_IPAD_PRO_1024{
        sizeOfFont = size + 12.0;
    }else if (IS_IPAD_PRO_1112){
        sizeOfFont = size + 10.0;
    }else if (IS_IPAD_PRO_1366){
        sizeOfFont = size + 20.0;
    }
    
    if IS_IPHONE, sizeOfFont == nil{
        sizeOfFont = size + 4.0
    }
    if IS_IPAD, sizeOfFont == nil{
        sizeOfFont = size + 10.0
    }
    
    return sizeOfFont!
}

extension UIFont {
    class func fontWithSize(size: CGFloat) -> CGFloat{
        return calculateSize(enter: size)
    }
    
    class func Montserrat_Bold(size: CGFloat) -> UIFont {
        
        print(calculateSize(enter: size))
        return UIFont(name: "Montserrat-Bold", size: calculateSize(enter: size))!
    }

    class func Montserrat_Regular(size: CGFloat) -> UIFont {
        return UIFont(name: "Montserrat-Regular", size: calculateSize(enter: size))!
    }
   
}


open class ReachabilityNet {
       class func isLocationServiceEnabled() -> Bool {
           if CLLocationManager.locationServicesEnabled() {
               switch(CLLocationManager.authorizationStatus()) {
                   case .notDetermined, .restricted, .denied:
                   return false
                   case .authorizedAlways, .authorizedWhenInUse:
                   return true
                   default:
                   print("Something wrong with Location services")
                   return false
               }
           } else {
                   print("Location services are not enabled")
                   return false
             }
           }
    
    
    class func hasLocationPermission() -> Bool {
        var hasPermission = false
        let manager = CLLocationManager()
        
        if CLLocationManager.locationServicesEnabled() {
            switch manager.authorizationStatus {
            case .notDetermined, .restricted, .denied:
                hasPermission = false
            case .authorizedAlways, .authorizedWhenInUse:
                hasPermission = true
            @unknown default:
                    break
            }
        } else {
            hasPermission = false
        }
        
        return hasPermission
    }
        }


