//
//  MyTextField.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

protocol MyTextFieldDelegate: AnyObject {
    func textFieldDidDelete(_ textField: UITextField)

}


import UIKit
class MyTextField: UITextField {

    weak var myDelegate: MyTextFieldDelegate?


    override func deleteBackward() {
        super.deleteBackward()
        myDelegate?.textFieldDidDelete(self)
    

    }

}
