//
//  UIColor.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit
import Foundation


extension UIColor {
    
    public class var blackColorText : UIColor {
        return hexStringToUIColor(hex: "020202")
    }
    
    public class var parpelButton : UIColor {
        return hexStringToUIColor(hex: "5046BB")
    }
    
    public class var orangeColorText : UIColor{
        return hexStringToUIColor(hex: "FF7F5D")
    }
    
    public class var pinkColorText : UIColor{
        return hexStringToUIColor(hex: "FFFCF5")
    }
    
    public class var whiteColorText : UIColor{
        return hexStringToUIColor(hex: "FFFFFF")
    }
    
}


func hexStringToUIColor (hex:String) -> UIColor {
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt64 = 0
    Scanner(string: cString).scanHexInt64(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}



