//
//  UIStoryBoardList.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//


import Foundation
import UIKit

enum AppStoryboard : String {
    case Main = "Main"
  
    var instance : UIStoryboard {
        return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
    }
}
