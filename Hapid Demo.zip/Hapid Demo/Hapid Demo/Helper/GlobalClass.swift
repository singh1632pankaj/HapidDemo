//
//  GlobalClass.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 21/02/23.
//

import Foundation
import UIKit


public class GlobalClass {

    public static var city = ""

    public static var lat = 0.0
    public static var long = 0.0
  
}
