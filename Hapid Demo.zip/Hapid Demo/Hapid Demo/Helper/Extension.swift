//
//  Extension.swift
//  Hapid Demo
//
//  Created by Pankaj Kumar Singh on 19/02/23.
//

import UIKit
import Foundation
import CryptoKit
import MBProgressHUD

let screenHeightFactor = UIScreen.main.bounds.height/568
let screenWidthFactor  = UIScreen.main.bounds.width/320


extension UIViewController {
    //MARK: -  For hide keyword when tapped around
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    //MARK: -  For dismiss keyword
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
}



extension String {
  
    
    //MARK: -  Check valid mobile number
    var isValidMobileNo: Bool {
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phoneTest.evaluate(with: self)
        return isValidPhone
    }
    

    //MARK: -  For convert string to date
    func stringToDate(inputDateFormat: String = "yyyy-MM-dd hh:mm:ss a") -> (String , Date) {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = inputDateFormat
        guard let date = dateFormatter.date(from: self) else {
            return(self,Date())
        }
        
        return (self , date)
    }
    
    //MARK: -  For convert date to string
    func convertDateString(fromFormat sourceFormat : String!, toFormat desFormat : String!) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = sourceFormat
        let date = dateFormatter.date(from: self)
        dateFormatter.dateFormat = desFormat
        return dateFormatter.string(from: date!)
    }

}

extension Date {
    //MARK: - Get date using format "YYYYMMdd"
    func getCurrentDate(format : String = "yyyyMMdd") -> (String, Date) {
        let dateformat = DateFormatter()
        dateformat.timeZone = (NSTimeZone(name: "IST")! as TimeZone)
        dateformat.dateFormat = format
        let str = dateformat.string(from: self)
        return (str, self)
    }
    
    //MARK: -  Get local time
    func getLocalTime(format: String = "yyyy-MM-dd HH:mm:ss") -> (String , Date){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        let str = dateFormatter.string(from: self)
        
        
        if let date = dateFormatter.date(from: str) {
            dateFormatter.timeZone = TimeZone(abbreviation: "IST")
            var localTimeZoneAbbreviation: String { return dateFormatter.timeZone.abbreviation() ?? "UTC" }
            dateFormatter.locale = Locale.init(identifier: localTimeZoneAbbreviation)
            dateFormatter.dateFormat = format
            let currentDateString = dateFormatter.string(from: date)
            
            let currentDate = Calendar.current.date(byAdding: .minute, value: 30, to:  Calendar.current.date(byAdding: .hour, value: 5, to: date)!)!
            return (currentDateString,currentDate)
        }
        return (str , self)
    }
    
    //MARK: -  get utc to local
    func utcToLocal(dateStr: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        if let date = dateFormatter.date(from: dateStr){
            dateFormatter.timeZone = TimeZone.current
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ"
            return dateFormatter.string(from: date)
        }
        return nil
    }
}



class Hapid_DemoClass {
    
    var window: UIWindow?
    var progressHud = MBProgressHUD()
    
    class var shared : Hapid_DemoClass {
        struct Static {
            static let instance  = Hapid_DemoClass()
        }
        return Static.instance
        
    }
    
    
    func startLoader(_ view:UIView) {
        
        if progressHud.superview != nil {
            progressHud.hide(animated: false)
        }
        
        progressHud.bezelView.color = UIColor.blue
        progressHud.bezelView.style = .solidColor
        
        progressHud = MBProgressHUD.showAdded(to: view, animated: true)
        progressHud.show(animated: true)
    }
    
    
    func stopLoader() {
        progressHud.hide(animated: true)
    }
}



